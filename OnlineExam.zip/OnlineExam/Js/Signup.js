
$('#Location').click(function(){  
        alert('Please Wait....') 
        getLocation()

      }) 

$(window).ready(function()
{
  $('submit').attr('disabled','disabled')
})
$("#Loc").click(function(){

  $(this).remove();

})
$("#Location").click(function(){

  $(this).remove('')
  $("#location").html('Location')

})
function getLocation() {
     if (navigator.geolocation) 
     	 {
            
             navigator.geolocation.getCurrentPosition(showPosition);
         }
     else 
     { 
            alert("Geolocation is not supported by this browser.");
            window.location="FindNearPeple.php";
     
      }
 }
function showPosition(position){ 
          $('#lat').val(position.coords.latitude)
          $('#lag').val(position.coords.longitude)
          var localApi="https://maps.googleapis.com/maps/api/geocode/json?latlng="+position.coords.latitude+","+position.coords.longitude+"&key=AIzaSyAKkBcO30mbyXLvz6zaS0V0ClKRPtu5PTQ";
			alert('Your Location...')
		//alert(<?php echo $lat; ?>)
  			var xhttp = new XMLHttpRequest();
  			xhttp.onreadystatechange = function() {
    			if (this.readyState == 4 && this.status == 200) {
    				  var Data= JSON.parse(this.responseText)
              console.log(Data)
    				  console.log(Data['results'][0].formatted_address)
    				  document.getElementById('Loc').value=Data['results'][0].formatted_address;
    				}
  				};
  		xhttp.open("GET", "https://maps.googleapis.com/maps/api/geocode/json?latlng=21.240207,72.84909499999999&key=AIzaSyAKkBcO30mbyXLvz6zaS0V0ClKRPtu5PTQ", true);
 		 xhttp.send();
}  